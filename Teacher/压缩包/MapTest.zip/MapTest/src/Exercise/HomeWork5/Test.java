package Exercise.HomeWork5;

import java.io.File;


public class Test {
    public static void main(String[] args)  {
        Flow.flowPrint(new File("C:\\Users\\admin\\Desktop\\java笔记\\四月三十号\\5.1作业\\flow.log"));
    }
}
