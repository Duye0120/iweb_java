package Reflect;

public class User {
    public static String name = "zhanghuan";

    public static String getName() {
        return name;
    }

    public User() {
    }
}
