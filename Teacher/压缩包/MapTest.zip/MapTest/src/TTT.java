public class TTT {
    public static void main(String[] args) {
        System.out.println("sdadadasf".lastIndexOf("sf"));
    }
}
