package FileExercise;

public class Couter {
    private int count;

    public int getCount() {
        return count;
    }

    public void add() {
        this.count += 1;
    }

}
