package com;

import com.os.MyKit;
import com.os.myjdbc.DBUtil;
import com.os.op.InitOs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class App {
    static {
//        初始化池子
            Connection conn = null;
        PreparedStatement pst = null;
            try {
//                插入到数据库
                DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
                conn= dbUtil.getConn();
                pst = conn.prepareStatement("select * from staff ");
                ResultSet rs = pst.executeQuery();
                while (rs.next()){
                    if(rs.getString("status").equals(false)){
                        if(rs.getString("employeetype").equals("ture")){
                            InitOs.list.add(rs.getString("employeeid").substring(1));
                        }else{
                            InitOs.list.add(rs.getString("employeeid").substring(3));
                        }

                    }
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }finally {
                if(conn != null){
                    try {
                        conn.close();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
            }
        }

    public static void main(String[] args) {

//        new InitOs().createEmployee("wuzong?",false);
//        new InitOs().init();
//        System.out.println(new InitOs().updateEmployeeID("W1000", 0));
        System.out.println(new InitOs().updateStatus("W1000",false));
//        System.out.println(Integer.parseInt("1011") > Integer.parseInt("1102") );
        System.out.println(InitOs.list);
    }
}
