package com.os.myjdbc;
import java.sql.*;
public class DBUtil {
    private Connection conn = null;

    public DBUtil(String url ,String user,String password) throws ClassNotFoundException, SQLException {
//        加载驱动
        Class.forName("oracle.jdbc.driver.OracleDriver");
//        获取连接
        this.conn = DriverManager.getConnection(url,user,password);

    }

    public Connection getConn() {
        return conn;
    }
    public void close() throws SQLException {
        if(conn != null && conn.isClosed()){
            conn.close();
        }
    }
}
