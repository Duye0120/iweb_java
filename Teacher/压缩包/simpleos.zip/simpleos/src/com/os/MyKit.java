package com.os;

import com.os.myjdbc.DBUtil;
import org.junit.Test;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
*@author shark
*@date 2021/5/12 18:52
*desc 这是一个工具类用来提供工具
*/

public class MyKit {
//   数据库中有多少条数据
    public synchronized int  getNum()  throws SQLException, ClassNotFoundException {
        DBUtil zhanghuan = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
        Connection conn = zhanghuan.getConn();
        Statement statement = conn.createStatement();
        ResultSet resultSet = statement.executeQuery("select count(1) s from staff");
        while(resultSet.next()){
            return resultSet.getInt("s");
        }
        conn.close();
        return -1;
    }

//    插入数据库方法
    public void insetIn(String s,String employeeName,String employeeType){
        Connection conn = null;
        try {
//                插入到数据库
            DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
            conn= dbUtil.getConn();
            PreparedStatement pst = conn.prepareStatement("insert into  staff values(?,?,?,?)");
            pst.setString(1,s);
            pst.setString(2,employeeName);
            pst.setString(3,employeeType);
            pst.setString(4,"true");
            int i = pst.executeUpdate();
            if (i == 1){
                System.out.println("创建成功");
            }else{
                System.out.println("创建失败");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
    }
//    正则表达式判断是否有非法字符
    public  boolean isSpecialChar(String str) {
        String regEx = "[ _`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]|\n|\r|\t";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return m.find();
    }
//    判断是否有这个员工
    public boolean hasEmp(String id ){
        Connection conn = null;
        ResultSet rs = null;
        try {
            DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
            conn = dbUtil.getConn();
            PreparedStatement pst = conn.prepareStatement("select * from staff where employeeID = ?");
            pst.setString(1,id);
             rs = pst.executeQuery();
            if (!rs.next()) return false;
//            System.out.println(rs.getString("employeeType") + 1);
//            System.out.println(rs.getString("status")+ 2);
            if(rs.getString("employeeType").equals("true") && rs.getString("status").equals("true")) return true;
            return false;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
        return false;
    }
    public boolean hasEmp(String name ,boolean b ){
        Connection conn = null;
        ResultSet rs = null;
        try {
            DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
            conn = dbUtil.getConn();
            PreparedStatement pst = conn.prepareStatement("select * from staff where employeename = ?");
            pst.setString(1,name);
            rs = pst.executeQuery();
            ResultSet rs1 = rs;
            if (!rs.next()) return false;
            return true;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
        return false;
    }
    public ArrayList<String> box(String name){
        Connection conn = null;
        ResultSet rs = null;
        try {
            DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
            conn = dbUtil.getConn();
            PreparedStatement pst = conn.prepareStatement("select * from staff where employeename = ?");
            pst.setString(1,name);
            ArrayList<String> list = new ArrayList<>();
            rs = pst.executeQuery();
            while (rs.next()){
                if (rs.getString("employeeid").length() == 5){
                    list.add(rs.getString("employeeid").substring(1));
                }else{
                    list.add(rs.getString("employeeid").substring(3));
                }
            }
            return list;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
        return null;
    }
//    判断是否能更新状态
    public boolean canUpdate(String id ){
    Connection conn = null;
    ResultSet rs = null;
    try {
        DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
        conn = dbUtil.getConn();
        PreparedStatement pst = conn.prepareStatement("select * from staff where employeeID = ?");
        pst.setString(1,id);
        rs = pst.executeQuery();
        if (!rs.next()) return false;
//            System.out.println(rs.getString("employeeType") + 1);
//            System.out.println(rs.getString("status")+ 2);
        if(rs.getString("status").equals("false")) return false;
        return true;
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    } catch (SQLException throwables) {
        throwables.printStackTrace();
    }finally {
        if(rs != null){
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if(conn != null){
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
    return false;
}
//    对静态常量池排序
    public ArrayList<String> sort(ArrayList<String> list){
        ArrayList<String> l = list;
        Comparator<String> comparator = new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                if(Integer.parseInt(o1) > Integer.parseInt(o2)){

                    return 1;
                }
                if(Integer.parseInt(o1) < Integer.parseInt(o2)){
                    return -1;
                }
                return 0;
            }
        };
        Collections.sort(l,comparator);
        return l;
    }
//   更新状态
    public void update(String id){
        Connection conn = null;
        ResultSet rs = null;
        try {
            DBUtil dbUtil = new DBUtil("jdbc:oracle:thin:@127.0.0.1:1521:xe", "zhanghuan", "123456");
            conn = dbUtil.getConn();
            PreparedStatement pst = conn.prepareStatement("UPDATE staff set status = 'false' where employeeid = ?");
            pst.setString(1,id);
            int i = pst.executeUpdate();
            if( i == 1){
                System.out.println("更新成功！");
            }else{
                System.out.println("更新失败！");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }

    }


}
