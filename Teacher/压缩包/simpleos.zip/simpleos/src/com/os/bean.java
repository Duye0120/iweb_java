package com.os;

public class bean {
}
